#include "ListaPosInt.h"

#ifdef LISTA_POS_INT_IMP

struct _cabezalListaPosInt {
	//IMPLEMENTAR SOLUCION
};

ListaPosInt crearListaPosInt()
{
	//IMPLEMENTAR SOLUCION
	return NULL;
}

void agregar(ListaPosInt& l, int e, unsigned int pos)
{
	//IMPLEMENTAR SOLUCION
}

void borrar(ListaPosInt& l, unsigned int pos)
{
	//IMPLEMENTAR SOLUCION
}

int elemento(ListaPosInt l, unsigned int pos)
{
	//IMPLEMENTAR SOLUCION
	return 0;
}

bool esVacia(ListaPosInt l)
{
	//IMPLEMENTAR SOLUCION
	return true;
}

unsigned int cantidadElementos(ListaPosInt l)
{
	//IMPLEMENTAR SOLUCION
	return 0;
}

ListaPosInt clon(ListaPosInt l)
{
	//IMPLEMENTAR SOLUCION
	return NULL;
}

void destruir(ListaPosInt& l)
{
	//IMPLEMENTAR SOLUCION
}


#endif