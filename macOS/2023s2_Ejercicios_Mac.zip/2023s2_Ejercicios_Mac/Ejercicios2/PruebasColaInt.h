#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "ColaInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasColaInt(Prueba* pruebaConcreta);
