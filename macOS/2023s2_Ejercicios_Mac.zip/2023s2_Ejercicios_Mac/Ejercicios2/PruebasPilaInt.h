#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "PilaInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasPilaInt(Prueba* pruebaConcreta);
