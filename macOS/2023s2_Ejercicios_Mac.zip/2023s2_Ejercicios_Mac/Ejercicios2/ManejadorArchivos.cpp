#include "ManejadorArchivos.h"

vector<string> split(string str, char delimiter) {
	vector<string> vec;
	stringstream ss(str);
	string tok;

	while (getline(ss, tok, delimiter)) {
        tok.erase(remove(tok.begin(), tok.end(), '\r'), tok.end());
        vec.push_back(tok);
	}

	return vec;
}

bool replace(string& source, string const& find, string const& replace)
{
	bool found = false;
	for (string::size_type i = 0; (i = source.find(find, i)) != string::npos;)
	{
		found = true;
		source.replace(i, find.length(), replace);
		i += replace.length();
	}
	return found;
}

bool isInteger(const std::string & s)
{
	if (s.empty() || ((!isdigit(s[0])) && (s[0] != '-') && (s[0] != '+'))) return false;

	char * p;
	(void)strtol(s.c_str(), &p, 10);

	return (*p == 0);
}



ManejadorArchivos::ManejadorArchivos(char* rutaL, char* rutaC, char* rutaS)
{
	this->rutaL = rutaL;
	this->rutaC = rutaC;
	this->rutaS = rutaS;

	pCorrectas = 0;
	pNI = 0;
	pComentadas = 0;
	pIncorrectas = 0;
	puntajeObtenido = 0;
	puntajeTotal = 0;
	fCorrectas = 0;
	fIncorrectas = 0;
}

bool ManejadorArchivos::esIniSeccion(string & linea) const
{
	if (!Prefijo(linea, "-!-"))
		return false;

	pair<string, string> palabras = ObtenerPalabraReservada(linea);
	string tipoComando = palabras.first; //Puede ser Ini, Fin o un numero de prueba.

	if (tipoComando == "Ini") 
		return true;
	
	return false;
}

bool ManejadorArchivos::esFinSeccion(string & linea) const
{
	if (!Prefijo(linea, "-!-"))
		return false;

	pair<string, string> palabras = ObtenerPalabraReservada(linea);
	string tipoComando = palabras.first; //Puede ser Ini, Fin o un numero de prueba.

	if (tipoComando == "Fin") 
		return true;
	
	return false;
}

bool ManejadorArchivos::esFinDePrueba(string & linea) const
{
	if (!Prefijo(linea, "-!-"))
		return false;

	pair<string, string> palabras = ObtenerPalabraReservada(linea);		
	string tipoComando = palabras.first; //Puede ser Ini, Fin o un numero de prueba.

	if (tipoComando == "Ini" || tipoComando == "Fin") 
		return false;
	
	return true;
}

int ManejadorArchivos::obtenerNumeroDePrueba(string & linea) const
{
	pair<string, string> palabras = ObtenerPalabraReservada(linea);
	string tipoComando = palabras.first; //Puede ser Ini, Fin o un numero de prueba.
	return atoi(palabras.first.c_str());
}

bool ManejadorArchivos::AvanzarHastaProximaPrueba(ifstream &archivo, int &nroPrueba, string &textoRes, string &contenidoFin, bool imprimirIniFin, ofstream &salida) const
{
	string linea;
	textoRes = "";

	while (getline(archivo, linea))
	{
        linea.erase(remove(linea.begin(), linea.end(), '\r'), linea.end());
        if (esIniSeccion(linea) || esFinSeccion(linea))
		{
			if (imprimirIniFin)
			{
				pair<string, string> palabras = ObtenerPalabraReservada(linea);
				string contenido = palabras.second;
				if (esIniSeccion(linea))
					ImprimirInicio(salida, contenido); 
				else 
					ImprimirFin(salida, contenido); 
			}
		}
		else if (!esFinDePrueba(linea))
		{
			textoRes += linea + "\n";
		}
		else // llego al fin de la prueba
		{
			nroPrueba = obtenerNumeroDePrueba(linea);
			pair<string, string> palabras = ObtenerPalabraReservada(linea);
			contenidoFin = palabras.second;
			return true;
		}
	}

	nroPrueba = 0;
	textoRes = "";
	contenidoFin = "0-COMENTADA-COMENTADA-Se llega al fin del archivo de forma inesperada";

	return false;
}

void ManejadorArchivos::Comparar(bool mostrarSalidas, bool soloMostrarErrores)
{
	string lineaL, lineaC, textoL, textoC, contenidoFinL;
	int pruebaActualL = 0;

	ifstream archivoLectura;
	ifstream archivoCorreccion;
	ofstream salida;

	archivoLectura.open(rutaL, ios::in);
	archivoCorreccion.open(rutaC, ios::in);
	salida.open(rutaS);

	archivoCorreccion.clear();
	archivoCorreccion.seekg(0, ios::beg); //Reinicia la lectura del archivo.
	archivoLectura.clear();
	archivoLectura.seekg(0, ios::beg); //Reinicia la lectura del archivo.

	AvanzarHastaProximaPrueba(archivoLectura, pruebaActualL, textoL, contenidoFinL, false, salida);
	vector<string> resultados = split(contenidoFinL, '-');
	string comentarioL = resultados[3];

	while (getline(archivoCorreccion, lineaC))
	{
        lineaC.erase(remove(lineaC.begin(), lineaC.end(), '\r'), lineaC.end());
		if (esIniSeccion(lineaC) || esFinSeccion(lineaC))
		{
			pair<string, string> palabras = this->ObtenerPalabraReservada(lineaC);
			if (esIniSeccion(lineaC))
				ImprimirInicio(salida, palabras.second); 
			else {
				ImprimirFin(salida, palabras.second);

				if (pIncorrectas == 0 && pNI == 0 && pComentadas == 0)
				{
					fCorrectas++;
				}
				else
				{
					fIncorrectas++;
				}

				pCorrectas = 0;
				pIncorrectas = 0;
				pNI = 0;
				pComentadas = 0;

			}
		}
		else {
			if (!esFinDePrueba(lineaC))
			{
				textoC += lineaC + "\n";
			}
			else // llego al fin de la prueba
			{
				int pruebaActualC = obtenerNumeroDePrueba(lineaC);
				pair<string, string> palabras = ObtenerPalabraReservada(lineaC);
				resultados = split(palabras.second, '-'); //  PUNTAJE-XXX-YYY-Comentario de archivo de correccion
				string puntajeStr = resultados[0]; // Parte PUNTAJE de: PUNTAJE-XXX-YYY-Comentario
				double puntaje = atof(puntajeStr.c_str()); // Parte PUNTAJE de: PUNTAJE-XXX-YYY-Comentario
				string retornoEsperado = resultados[1]; // Parte XXX de: PUNTAJE-XXX-YYY-Comentario
				string retornoObtenido = resultados[2]; // Parte YYY de: PUNTAJE-XXX-YYY-Comentario
				string comentarioC = resultados[3];		// Parte Comentario de: PUNTAJE-XXX-YYY-Comentario

				puntajeTotal += puntaje;

				if (retornoEsperado != retornoObtenido) {
					assert(false); // la solucion o las pruebas son incorrectas
				}

				if (comentarioL != comentarioC) // la prueba no existe en el generado por alumno. no me muevo en el archivo de lectura
				{
					ImprimirComparacion(salida, pruebaActualC, textoL, textoC, "", "COMENTADA", comentarioC, puntaje, mostrarSalidas, soloMostrarErrores);
				}
				else // comparo las pruebas y avanzo en el archivo de lectura
				{
					resultados = split(contenidoFinL, '-'); // PUNTAJE-XXX-YYY-Comentario de archivo de alumno
					comentarioL = resultados[3];			// Parte Comentario de: PUNTAJE-XXX-YYY-Comentario	
					retornoObtenido = resultados[2];		// Parte YYY de: PUNTAJE-XXX-YYY-Comentario	
					ImprimirComparacion(salida, pruebaActualC, textoL, textoC, retornoEsperado, retornoObtenido, comentarioC, puntaje, mostrarSalidas, soloMostrarErrores);

					AvanzarHastaProximaPrueba(archivoLectura, pruebaActualL, textoL, contenidoFinL, false, salida);
					resultados = split(contenidoFinL, '-');
					comentarioL = resultados[3];
				}
				textoC = "";
			}
		}
	}

	ImprimirEstadisticas(salida);

	archivoLectura.close();
	archivoCorreccion.close();
	salida.close();
}


bool ManejadorArchivos::Prefijo(string linea, string pref) const
{
	return linea.compare(0, pref.length(), pref) == 0;
}

//PRE: Prefijo(linea, "-!-")
pair<string, string> ManejadorArchivos::ObtenerPalabraReservada(string linea) const
{
	std::size_t pos = linea.find("::");
	string izq = linea.substr(3, pos-3); //Desde 2 para sacar el "-!-"
	string der = linea.substr(pos+2);

	return pair<string, string>(izq, der);
}

void ManejadorArchivos::ImprimirInicio(ofstream &salida, string titulo) const
{
	salida << "********* INICIO " << titulo << "*******" << endl;
}

void ManejadorArchivos::ImprimirFin(ofstream &salida, string titulo) const
{
	salida << "********* FIN " << titulo << "*******" << endl << endl;
	if (pIncorrectas == 0 && pNI == 0 && pComentadas == 0)
		salida << "PRUEBAS FUNCION " << setw(50) << std::left << titulo << " PRUEBAS CORRECTAS" << endl << endl;
	else
	{
		int pruebasErroneas = pIncorrectas + pNI + pComentadas;
		salida << "PRUEBAS FUNCION " << setw(50) << std::left << titulo << " HAY " << pruebasErroneas << " PRUEBAS INCORRECTAS" << endl << endl;
	}
}

// Compara la salida esperada contra la obtenida.
void ManejadorArchivos::ImprimirComparacion(ofstream &salida, int nroPrueba, string obt, string esp, string retE, string retO, string com, double puntaje, bool mostrarSalidas, bool soloMostrarErrores) 
{
	if (MismaImpresion(esp, obt) && retO == retE)
	{
		this->pCorrectas++;
		puntajeObtenido += puntaje;
		if (soloMostrarErrores) return;
		salida << "-----------------------------------" << endl;
		salida << "Prueba " << nroPrueba << ": " << com;
		salida << " -> OK" << endl;
		if (mostrarSalidas && obt != "")
			salida << endl << "Se imprimio: " << endl << obt << endl;
	}
	else if (retO == "COMENTADA")
	{
		salida << "-----------------------------------" << endl;
		salida << "Prueba " << nroPrueba << ": " << com;
		salida << endl << " -> ERROR PRUEBA COMENTADA" << endl;
		this->pComentadas++;
	}else if (retO == "NO_IMPLEMENTADA")
	{
		salida << "-----------------------------------" << endl;
		salida << "Prueba " << nroPrueba << ": " << com;
		salida << endl << " -> ERROR PRUEBA NO_IMPLEMENTADA" << endl;
		this->pNI++;
	}
	else {
		salida << "-----------------------------------" << endl;
		salida << "Prueba " << nroPrueba << ": " << com;
		if (retO != retE)
		{
			salida << endl << " -> ERROR retorno incorrecto" << endl;
			salida << "\t Se esperaba: " << retE << endl;
			salida << "\t Se obtuvo: " << retO << endl;
		}
		if (!MismaImpresion(esp, obt)) {
			salida << endl << " -> ERROR impresion incorrecta" << endl;
			ImprimirEsperadoVsRecibido(salida, esp, obt);
		}
		this->pIncorrectas++;
	}
}


// Imprimo el resultado esperado vs el recibido
// Mostrar la linea (y posicion) en la que hay diferencia
// Marcar la linea con la diferencia
// TODO: No imprimir lineas vacias que esten al final
void ManejadorArchivos::ImprimirEsperadoVsRecibido(ofstream &salida, string &esp, string &obt) const
{
	vector<string> vecEsp = split(esp, '\n');
	vector<string> vecObt = split(obt, '\n');
	unsigned int iEsp = 1, iObt = 1;

	salida << "Se esperaba imprimir (el numero de linea fue agregado, no se debe imprimir): " << endl;
	for(vector<string>::const_iterator i = vecEsp.begin(); i != vecEsp.end(); ++i) {
		salida << setw(2) << iEsp++ << setw(0) << ": " << *i << endl; 
		salida << setw(0);
	}

	salida << endl;
	salida << "Se imprimio (el numero de linea fue agregado, no se debe imprimir): " << endl;
	salida << "(Los numeros de linea aparecen con : si coinciden y ! si no coinciden)" << endl;
	for(vector<string>::const_iterator i = vecObt.begin(); i != vecObt.end(); ++i) {
		salida << setw(2) << iObt++ << setw(0);
		if (iObt <= iEsp && MismaImpresion(vecObt[iObt-2], vecEsp[iObt-2]))
		{
			salida << ": ";
		}
		else
		{
			salida << "! ";
		}
		salida << *i << endl; 
		salida << setw(0);
	}

}

void ManejadorArchivos::ImprimirEstadisticas(ofstream &salida) const
{
	salida << endl << endl << "----------------" << endl;
	salida << "PRUEBAS FUNCIONES " << endl;
	salida << "PRUEBAS FUNCIONES RESULTADO " << setw(35) << std::left << rutaC << " =>" << " CORRECTAS: " << setw(2) << std::right << fCorrectas << " INCORRECTAS: " << setw(2) << std::right << fIncorrectas << endl;
	salida << "PRUEBAS FUNCIONES " << endl;
	//salida << "PRUEBAS CORRECTAS: " << this->pCorrectas << endl;
	//salida << "PRUEBAS INCORRECTAS: " << this->pIncorrectas << endl;
	//salida << "PRUEBAS NO IMPLEMENTADAS: " << this->pNI << endl;
	//salida << "PRUEBAS COMENTADAS: " << this->pComentadas << endl;
	if (puntajeTotal > 0) {
		salida << endl;
		salida << "PUNTAJE TOTAL: " << this->puntajeTotal << endl;
		salida << "PUNTAJE OBTENIDO: " << this->puntajeObtenido << endl;
	}
}

bool removeFromStart(string& source, string const& find)
{
	std::string::size_type i = source.find(find);
	if (i != std::string::npos && i == 0)
	{
		source.erase(i, find.length());
		return true;
	}
	return false;
}

bool removeFromEnd(string& source, string const& find)
{
	std::string::size_type i = source.find_last_of(find);
	if (i != std::string::npos && i == source.length() - 1)
	{
		source.erase(i, 1);
		return true;
	}
	return false;
}


bool trimFromEnd(std::string &s) {
	// trim trailing spaces
	std::string::size_type i = s.find_last_of(" \t");
	if(i != std::string::npos && i == s.length()-1)
	{
		s = s.erase(i, 1);
		return true;
	}
	return false;
}

bool ManejadorArchivos::MismaImpresion(string esp, string obt) const
{
	if (esp == "" && obt == "")
		return true;
	
	while (true)
	{
		bool b = false;
		b = b || removeFromStart(esp, "\n");	// quito lineas en blanco al inicio	
		b = b || removeFromEnd(esp, "\n");		// quito lineas en blanco al final
		b = b || trimFromEnd(esp);				// quito espacios al final	
		b = b || replace(esp, " \n", "\n");		// quito espacios al final de cada linea
		b = b || replace(esp, "\t\n", "\n");	// quito tabuladores al final de cada linea
		b = b || replace(esp, ".\n", "\n");		// quito punto al final de cada linea (ERROR)
		b = b || removeFromEnd(esp, ".");		// quito punto al final
		b = b || removeFromEnd(esp, "\t");		// quito tabulador al final
		b = b || replace(esp, "  ", " ");		// reemplazo dos o mas espacios por espacio
		b = b || replace(esp, "\t", " ");		// reemplazo tabuladores por espacios

		//b = b || replace(esp, "- Alarma: ", "- Alarma ");		// reemplazo tabuladores por espacios
		
		if (!b) break;
	}
	while (true)
	{
		bool b = false;
		b = b || removeFromStart(obt, "\n");	// quito lineas en blanco al inicio	
		b = b || removeFromEnd(obt, "\n");		// quito lineas en blanco al final
		b = b || trimFromEnd(obt);				// quito espacios al final	
		b = b || replace(obt, " \n", "\n");		// quito espacios al final de cada linea
		b = b || replace(obt, "\t\n", "\n");	// quito tabuladores al final de cada linea
		b = b || replace(obt, ".\n", "\n");		// quito punto al final de cada linea (ERROR)
		b = b || removeFromEnd(obt, ".");		// quito punto al final
		b = b || removeFromEnd(obt, "\t");		// quito tabulador al final
		b = b || replace(obt, "  ", " ");		// reemplazo dos o mas espacios por espacio
		b = b || replace(obt, "\t", " ");		// reemplazo tabuladores por espacios

		//b = b || replace(obt, "- Alarma: ", "- Alarma ");		// reemplazo tabuladores por espacios
		//b = b || replace(obt, "ERROR: No existe luz con ese numero", "ERROR: No existe una luz con ese numero");		// reemplazo tabuladores por espacios

		if (!b) break;
	}

	//if (esp.rfind("ERROR: ", 0) == 0 && obt.rfind("ERROR: ", 0) == 0) return true;

	//replace(esp, "\n\n", "\n");
	return esp == obt;
}
