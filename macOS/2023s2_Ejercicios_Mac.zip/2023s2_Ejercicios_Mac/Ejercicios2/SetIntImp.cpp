#include "SetInt.h"

#ifdef SET_INT_IMP

struct _cabezalSetInt {
	// NO IMPLEMENTADO
};

SetInt crearSetInt(){
	// NO IMPLEMENTADO
	return NULL;
}

void agregar(SetInt& s, int e) {
	// NO IMPLEMENTADO
}

void borrar(SetInt& s, int e) {
	// NO IMPLEMENTADO
}

bool pertenece(SetInt s, int e) {
	// NO IMPLEMENTADO
	return false;
}

SetInt unionConjuntos(SetInt s1, SetInt s2) {
	// NO IMPLEMENTADO
	return NULL;
}

SetInt interseccionConjuntos(SetInt s1, SetInt s2) {
	// NO IMPLEMENTADO
	return NULL;
}

SetInt diferenciaConjuntos(SetInt s1, SetInt s2) {
	// NO IMPLEMENTADO
	return NULL;
}

bool contenidoEn(SetInt s1, SetInt s2) {
	// NO IMPLEMENTADO
	return false;
}

int elemento(SetInt s) {
	// NO IMPLEMENTADO
	return 0;
}

bool esVacio(SetInt s) {
	// NO IMPLEMENTADO
	return true;
}

unsigned int cantidadElementos(SetInt s) {
	// NO IMPLEMENTADO
	return 0;
}

void destruir(SetInt& s) {
	// NO IMPLEMENTADO
}

SetInt clon(SetInt s) {
	// NO IMPLEMENTADO
	return NULL;
}

#endif