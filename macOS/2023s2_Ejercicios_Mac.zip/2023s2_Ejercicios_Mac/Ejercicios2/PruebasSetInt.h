#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "SetInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasSetInt(Prueba* pruebaConcreta);
