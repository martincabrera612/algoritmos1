#pragma once

enum _tipoPruebas
{
	Correccion, Defensa, Propias, EjemploDeUsoEntrega
};
typedef enum _tipoPruebas TipoPruebas;

//const char* TipoPruebas_STRING[] = {
//	"Correccion", "Defensa", "Propias", "EjemploDeUsoEntrega1", "EjemploDeUsoEntrega2"
//};

