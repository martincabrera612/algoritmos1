#ifndef IMPRACIONAL_H
#define IMPRACIONAL_H

#include <iostream>
#include <assert.h>
#include "Racional.h"

class ImpRacional : public Racional{
public:
//	postcondicion: el racional que se crea usando el constructor sin par�metros es 0/1
	ImpRacional();

//	precondicion: n y d con enteros.
//				d es diferente de 0
//	postcondicion: el racional que se crea usando este constructor es n/d
//	este metodo equivale a CrearRacional
	ImpRacional(int n, int d);

	virtual ~ImpRacional();

	void setNumerador(int n);

	int getNumerador();

	void setDenominador(int d);

	int getDenominador();

	Racional& operator+(Racional &sumando);

	Racional& operator-(Racional &sustraendo);

	Racional& operator=(Racional &r);

	void ProductoRacional(Racional* factor);

	void CocienteRacional(Racional* divisor);

	void IngresoRacional(Racional* r);

	void BorrarRacional();

	void EscribirRacional();

	bool esValido();

private:
	int num;
	int den;

//	precondici�n: x e y son enteros
//	retorna: el MCD de x e y
	int Mcd(int x, int y);

//	precondici�n: this es un racional v�lido
//	postcondici�n: this queda normalizado
	void Normalizar();
};




#endif