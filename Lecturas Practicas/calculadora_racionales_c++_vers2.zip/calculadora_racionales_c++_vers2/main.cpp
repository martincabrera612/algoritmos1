/*
CALCULADORA DE RACIONALES USANDO EL LENGUAJE C++
El programa que simula la calculadora se encuentra en este archivo (main.cpp),
la especificacion del TAD Racional se encuentra en Racional.h
y una implementacion en ImpRacional.cpp


Esta implementaci�n de una calculadora de racionales es una ligera variante
de la presentada en el te�rico del curso Estructuras de Datos y Algoritmos 1.
Un racional p/q es v�lido si q es distinto de cero.
El sistema no deber� permitir operar con racionales inv�lidos.
BorrarRacional deja el racional 0/1 sobre el visor.

EL PROGRAMA QUE SIMULA EL FUNCIONAMIENTO DE LA CALCULADORA
*/

#include <iostream>
#include "ImpRacional.h"
using namespace std;

void main(){
	int num, den;
	Racional* visor = new ImpRacional(0,1);
	Racional* operando = new ImpRacional();
	enum Comando {SUMA, RESTA, PRODUCTO, COCIENTE, BORRAR, INGRESO, FIN};
	enum Comando comando;
	printf("INSTRUCCIONES: Introduzca numeros en formato a/b\n");
	printf("Comandos: 0-SUMA ,1-RESTA, 2-PRODUCTO, 3-COCIENTE, 4-BORRAR, 5-INGRESO, 6-FIN\n\n");
	printf("VISOR: ");
	visor->EscribirRacional();
	printf("Comando: ");
	scanf("%d", &comando);
	while (comando!=FIN){
		switch (comando){
		case SUMA:
			printf("Operando: ");
			scanf("%d/%d", &num, &den);
			operando->setNumerador(num);
			operando->setDenominador(den);
			*visor=*visor+*operando;
			break;
		case RESTA:
			printf("Operando: ");
			scanf("%d/%d", &num, &den);
			operando->setNumerador(num);
			operando->setDenominador(den);
			*visor=*visor-*operando;
			break;
		case PRODUCTO:
			printf("Operando: ");
			scanf("%d/%d", &num, &den);
			operando->setNumerador(num);
			operando->setDenominador(den);
			visor->ProductoRacional(operando);
			break;
		case COCIENTE:
			printf("Operando: ");
			scanf("%d/%d", &num, &den);
			operando->setNumerador(num);
			operando->setDenominador(den);
			visor->CocienteRacional(operando);
			break;
		case BORRAR:
			visor->BorrarRacional();
			break;
		case INGRESO:
			printf("Operando: ");
			scanf("%d/%d", &num, &den);
			operando->setNumerador(num);
			operando->setDenominador(den);
			visor->IngresoRacional(operando);
			break;
		default:
			printf("COMANDO NO VALIDO\n");
		}
		if (comando==SUMA || comando==RESTA || comando==PRODUCTO || comando==COCIENTE || comando==BORRAR || comando==INGRESO)
			printf("VISOR: ");
			visor->EscribirRacional();
		printf("Comando: ");
		scanf("%d", &comando);
	}
	delete visor;
	delete operando;
}