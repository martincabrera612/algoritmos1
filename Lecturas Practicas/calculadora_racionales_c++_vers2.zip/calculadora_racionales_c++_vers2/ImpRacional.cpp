//ImpRacional.cpp
//Este archivo contiene una posible implementaci�n del Tad Racional

#ifndef IMPRACIONAL_CPP
#define IMPRACIONAL_CPP

#include "ImpRacional.h"
using namespace std;

//	postcondicion: el racional que se crea usando el constructor sin par�metros es 0/1
ImpRacional::ImpRacional(){
	num=0;
	den=1;
}

//	precondicion: n y d con enteros.
//				d es diferente de 0
//	postcondicion: el racional que se crea usando este constructor es n/d
//	este metodo equivale a CrearRacional
ImpRacional::ImpRacional(int n, int d){
	assert(d!=0);
	num=n;
	den=d;
}

ImpRacional::~ImpRacional(){

}

void ImpRacional::setNumerador(int n){
	num=n;
}

int ImpRacional::getNumerador(){
	assert(esValido());
	return num;
}

void ImpRacional::setDenominador(int d){
	assert(d!=0);
	den=d;
}

int ImpRacional::getDenominador(){
	assert(esValido());
	return den;
}

Racional& ImpRacional::operator+(Racional &sumando){
	assert(esValido()&&sumando.esValido());
	num=num*sumando.getDenominador()+sumando.getNumerador()*den;
	den=den*sumando.getDenominador();
	Normalizar();
	return *this;
}

Racional& ImpRacional::operator-(Racional &sustraendo){
	assert(esValido()&&sustraendo.esValido());
	num=num*sustraendo.getDenominador()-sustraendo.getNumerador()*den;
	den=den*sustraendo.getDenominador();
	Normalizar();
	return *this;
}

Racional& ImpRacional::operator=(Racional &r){
	assert(r.esValido());
	num=r.getNumerador();
	den=r.getDenominador();
	Normalizar();
	return *this;
}

void ImpRacional::ProductoRacional(Racional* factor){
	assert(esValido()&&factor->esValido());
	num=num*factor->getNumerador();
	den=den*factor->getDenominador();
	Normalizar();
}

void ImpRacional::CocienteRacional(Racional* divisor){
	assert(esValido()&&divisor->esValido()&&divisor->getNumerador()!=0);
	num=num*divisor->getDenominador();
	den=den*divisor->getNumerador();
	Normalizar();
}

void ImpRacional::IngresoRacional(Racional* r){
	assert(r->esValido());
	num=r->getNumerador();
	den=r->getDenominador();
	Normalizar();
}

void ImpRacional::BorrarRacional(){
	num=0;
	den=1;
}

void ImpRacional::EscribirRacional(){
	assert(esValido());
	printf("%d/%d\n", num, den);
}

bool ImpRacional::esValido(){
	return den!=0;
}


//	precondici�n: x e y son enteros
//	retorna: el MCD de x e y
int ImpRacional::Mcd(int x, int y){
	int retorno;
	if(y==0){
		retorno=x;
	}
	else{
		retorno=Mcd(y, x%y);
	}
	return retorno;
}

//	precondici�n: this es un racional v�lido
//	postcondici�n: this queda normalizado
void ImpRacional::Normalizar(){
	assert(esValido());
	int mcd=Mcd(num,den);
	num=num/mcd;
	den=den/mcd;
}
#endif
 