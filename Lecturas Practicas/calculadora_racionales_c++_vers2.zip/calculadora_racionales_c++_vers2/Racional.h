//Racional.h
//Este archivo contiene la especificaci�n del TAD Racional

#ifndef RACIONAL_H
#define RACIONAL_H

class Racional{
public:
	virtual void setNumerador(int n)=0;
//	precondicion: n es un entero
//	postcondicion: el numerador del racional que responder� al metodo (en adelante "this")
//		pasa a ser n
	
	virtual int getNumerador()=0;
//	precondici�n: this es un racional v�lido
//	retorna: el numerador de this
//	este metodo equivale a Numerador

	virtual void setDenominador(int d)=0;
//	precondicion: d es un entero diferente de 0
//	postcondicion: el denominador de this pasa a ser d

	virtual int getDenominador()=0;
//	precondici�n: this es un racional v�lido
//	retorna: el denominador de this
//	este metodo equivale a Denominador

	virtual Racional& operator+(Racional &sumando)=0;
//	precondici�n: this es un racional v�lido Q
//      sumando es un racional v�lido R
//	postcondici�n: this es el racional Q + R
//	retorna: this
//	este metodo equivale a SumaRacional

	virtual Racional& operator-(Racional &sustraendo)=0;
//	precondici�n: this es un racional v�lido Q
//		sustraendo es un racional v�lido R
//	postcondici�n: this es el racional Q - R
//	retorna: this
//	este metodo equivale a RestaRacional

	virtual Racional& operator=(Racional &r)=0;
//	precondici�n: r es una referencia a un racional v�lido
//	postcondici�n: this = r, pero normalizado
//	retorna: this
//	este metodo equivale a IngresoRacional

	virtual void ProductoRacional(Racional* factor)=0;
//	precondici�n: this es un racional v�lido Q
//		factor es una referencia a un racional v�lido R
//	postcondici�n: this es el racional Q * R

	virtual void CocienteRacional(Racional* divisor)=0;
//	precondici�n: this es un racional v�lido Q
//		divisor es una referencia a un racional v�lido R.
//		El numerador de R es distinto de 0.
//	postcondici�n: this es al racional Q / R

	virtual void IngresoRacional(Racional* r)=0;
//	precondici�n: r es una referencia a un racional v�lido
//	postcondici�n: this = r, pero normalizado;

	virtual void BorrarRacional()=0;
//	postcondici�n: this pasa a ser el racional 0/1

	virtual void EscribirRacional()=0;
//	precondici�n: this es un racional v�lido
//	postcondici�n: imprime por pantalla el racional this;

	virtual bool esValido()=0;
//	retorna: true si el denominador de this es distinto de cero o false en caso contrario

};

#endif


