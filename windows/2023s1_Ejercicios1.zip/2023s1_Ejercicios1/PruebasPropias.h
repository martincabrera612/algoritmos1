#ifndef PRUEBASPROPIAS_H
#define PRUEBASPROPIAS_H

#include "FuncAux.h"
#include "PruebasAuxComienzo.h"
#include "PruebasAuxListas.h"
#include "PruebasAuxArboles.h"

void PruebasPropias();

#endif