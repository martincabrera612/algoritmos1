#include "PruebasPropias.h"

#ifndef PRUEBASPROPIAS_CPP
#define PRUEBASPROPIAS_CPP

void PruebasPropias() {


}


#endif