#pragma once

#include "PruebasAuxListas.h"
#include "FuncAux.h"

void PruebasListas();
