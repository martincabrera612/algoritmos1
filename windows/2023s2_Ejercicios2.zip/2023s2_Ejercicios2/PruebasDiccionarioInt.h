#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "DiccionarioInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasDiccionarioInt(Prueba *pruebaConcreta);
