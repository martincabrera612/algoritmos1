#pragma once

#ifdef LISTA_ORD_INT_IMP_2

#include <iostream>
using namespace std;
#include <assert.h>

#endif
