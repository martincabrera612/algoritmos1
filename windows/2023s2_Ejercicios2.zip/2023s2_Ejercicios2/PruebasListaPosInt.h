#pragma once

#include <iostream>
using namespace std;
#include <assert.h>

#include "Prueba.h"
#include "FuncAux.h"
#include "ListaPosInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasListaPosInt(Prueba* pruebaConcreta);
