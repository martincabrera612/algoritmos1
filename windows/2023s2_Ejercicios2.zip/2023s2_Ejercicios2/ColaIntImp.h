#pragma once

// NOTA: Este archivo solo se puede modificar para agregar algun include en caso de ser necesario (opcional)

#ifdef COLA_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>

#endif
