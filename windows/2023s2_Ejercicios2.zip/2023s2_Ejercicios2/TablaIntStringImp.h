#pragma once

#ifdef TABLA_INT_STRING_IMP

#include <iostream>
using namespace std;
#include <assert.h>
#include <string.h>

#endif
