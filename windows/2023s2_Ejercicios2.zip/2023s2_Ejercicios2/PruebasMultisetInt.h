#pragma once

#include "Prueba.h"
#include "FuncAux.h"
#include "MultisetInt.h"

// PRE: 
// POS: Inicia el testeo del TAD
void pruebasMultisetInt(Prueba* pruebaConcreta);
