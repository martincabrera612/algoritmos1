#pragma once

#ifdef COLAPRIORIDAD_INT_IMP

#include <iostream>
using namespace std;
#include <assert.h>

#endif
