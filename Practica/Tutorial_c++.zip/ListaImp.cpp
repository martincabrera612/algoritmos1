#include "ListaImp.h"

template<class Etype>
ListaImp<Etype>::ListaImp()
{
	primero = ultimo = actual = NULL;
	cantElementos = 0;
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template<class Etype>
ListaImp<Etype>::ListaImp(Lista<Etype>* lista)
{
	primero = ultimo = actual = NULL;
	lista->comienzo();
	for(int i=0;i < lista->cardinal();i++)
	{
		insertar(*(lista->elementoActual()));
		lista->siguiente();
	}
	cantElementos = lista->cardinal();
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template<class Etype>
void ListaImp<Etype>::borrar(PtrNodo a)
{
	cantElementos--;
	PtrNodo aux = a;
	if(primero==a) primero = a->getSiguiente();
	if(ultimo==a) ultimo = a->getAnterior();
	if(a->getAnterior()!=NULL){
		a->getAnterior()->setSiguiente(a->getSiguiente());
	}
	if(aux->getSiguiente()!=NULL){
		a->getSiguiente()->setAnterior(a->getAnterior());
	}
	delete aux;
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template<class Etype>
void ListaImp<Etype>::vacia(){
	primero = ultimo = actual = NULL;
	cantElementos = 0;
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class Etype>
void ListaImp<Etype>::insertar(const Etype &x)
{
	PtrNodo aux = new NodoDoble<Etype>(x);
	if(esVacia())
	{
		primero = ultimo = actual = aux;
	}else
	{
		ultimo->setSiguiente(aux);
		aux->setAnterior(ultimo);
		ultimo = aux;
	}
	cantElementos ++;
};
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class Etype>
void ListaImp<Etype>::borrarLista()
{
	comienzo();
	PtrNodo aux = new NodoDoble<Etype>;
	while (actual !=NULL)
	{
		aux->setSiguiente(actual->getSiguiente());
		delete actual;
		actual = aux;
	}
	delete aux;
};
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template<class Etype>
void ListaImp<Etype>::operator=(Lista<Etype>* lista)
{
	cantElementos = lista->cardinal();
	lista->comienzo();
	for(int i=0;i<cantElementos;i++)
	{
		insertar(*(lista->elementoActual()));
		lista->siguiente();
	}
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template <class Etype>
ostream& operator<<(ostream& out,Lista<Etype> &lista){
	out<< endl;
	if(lista.esVacia())
	{
		out << "Lista vacia"<<endl;
	}else
	{
		out << "----->"<<endl;
		lista.comienzo();
		for(int i=0;i<lista.cardinal();i++)
		{
			out << *lista.elementoActual()<<"\t";
			lista.siguiente();
		}
		out<< "\n";
		out << "<------"<<endl;
	}
	return out;
};
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////