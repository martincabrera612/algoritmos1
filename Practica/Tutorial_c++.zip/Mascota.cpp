// Mascota.cpp: implementation of the Mascota class.
//
//////////////////////////////////////////////////////////////////////

#include "Mascota.h"
#include "ListaImp.cpp"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Mascota::Mascota()
{
	nombre="";
	raza="";
	edad=0;
	listaVacunas= new ListaImp<Vacuna*>;
}

Mascota::~Mascota()
{

}

void Mascota::setNombre(char* unN)
{
	nombre= unN;
}

char* Mascota::getNombre()
{
	return nombre;
}

void Mascota::setEdad(int unaE)
{
	edad= unaE;
}

int Mascota::getEdad()
{
	return edad;
}

void Mascota::setRaza(char* unaR)
{
	raza= unaR;
}

char* Mascota::getRaza()
{
	return raza;
}

void Mascota::imprimir()
{

}

void Mascota::imprimirMascota()
{
	cout<<"Nombre: "<<this->getNombre()<<endl;
	cout<<"Edad: "<<this->getEdad()<<endl;
	cout<<"Raza: "<<this->getRaza()<<endl;
	if(this->getListaVacunas()->esVacia())
	{
		cout<<"No tiene ninguna vacuna"<<endl;
	}
	else
	{
		cout<< "Vacunaciones:"<<endl;
		imprimirVacunas();
		cout<< endl;
	}
}

void Mascota::agregarVacuna(char* nombre, char* medico)
{
	Vacuna *v= new Vacuna;
	v->nombre= nombre;
	v->medicoResponsable= medico; 
	listaVacunas->insertar(v);
}


Lista<Vacuna *>* Mascota::getListaVacunas()
{
	return listaVacunas;
}

void Mascota::imprimirVacunas()
{
	Vacuna* vacuna;
	listaVacunas->comienzo();	
	for (int i=1;i <= listaVacunas->cardinal();i++)
	{
		vacuna = *(listaVacunas->elementoActual());
		cout << "Nombre: " << vacuna->nombre << endl;
		cout << "Medico resp.: " << vacuna->medicoResponsable << endl;
		listaVacunas->siguiente();
	}
}
