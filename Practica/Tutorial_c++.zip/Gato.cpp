#pragma once

#include "Gato.h"
#include <iostream>
using namespace std;

Gato::Gato()
{
	cantidadDeVidas= 0;
}

Gato::~Gato()
{

}

void Gato::setVidas(int unaV)
{
	cantidadDeVidas= unaV;
}

int Gato::getVidas()
{
	return cantidadDeVidas;
}

void Gato::imprimir()
{
	cout<<"************ Gato ************"<<endl;
	this->imprimirMascota();
	cout<<"Cantidad de vidas "<<this->getVidas()<<endl;
	cout<<"******************************"<<endl<<endl;
}
