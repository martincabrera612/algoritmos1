#pragma once

#include "Mascota.h"

class Perro: public Mascota
{

//Desclaraci�n de variables
private: 
	bool patente;

public:
	
	//M�todos de Acceso y Modificaci�n
	bool getPatente();
	void setPatente(bool);
	
	//M�todos auxiliares
	void imprimir();

	//Constructor y Destructor
	Perro();
	virtual ~Perro();
};