// NodoDoble.h: interface for the NodoDoble class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <iostream>
using namespace std;

template < class Etype >
class NodoDoble  
{

friend ostream& operator<<(ostream& out,const NodoDoble<Etype> &nodo);

private:
	//Atributos de la clase/////////////
	Etype	dato;
	NodoDoble*	siguiente;
	NodoDoble*	anterior;
	////////////////////////////////////

	typedef NodoDoble* PtrNodo;

public:
	NodoDoble();	
	NodoDoble(Etype unD);
	NodoDoble(NodoDoble<Etype>* unN);

	//M�todos p�blicos/////////////////////////////////////////////
	void	setAnterior(PtrNodo ptr)		{	anterior = ptr;	 }
	void	setSiguiente(PtrNodo ptr)		{	siguiente = ptr; }
	PtrNodo getAnterior()					{	return anterior; }
	PtrNodo getSiguiente()					{	return siguiente;}	
	void	setDato(Etype unD)				{	dato = unD;	 }
	Etype	getDato()const					{	return dato; }
	Etype*	getDireccionDelDato()			{	return &dato;}
	///////////////////////////////////////////////////////////////
		
	//Redefinici�n de Operadores //////////////////
	void	operator=(const NodoDoble<Etype> &unN);
	///////////////////////////////////////////////


};
