#pragma once
template <class Etype>

class Lista{
	

public:

	virtual void vacia()=0; 
		/*	Precondici�n: ________
			Postcondici�n: La lista queda vac�a.-
		*/	
	virtual void insertar(const Etype &x)=0; //Inserta el x en la posici�n actual.-
		/*	Precondici�n: _______
			Postcondici�n: Inserta el elemento x en la posicion actual de la lista.
			               Queda el nuevo elemento en la posici�n actual-
		*/
	virtual	bool esVacia()const=0; 
		/*	Precondici�n: ________
			Postcondici�n: Retorna true si la lista es vac�a.-
		*/	
	virtual Etype* elementoActual()const=0; 
		/*	Precondici�n: Lista no vac�a.-
			Postcondici�n: Retorna el elemento en pos. corriente.-
		*/
	virtual void siguiente()=0; 
		/*	Precondici�n: Lista no vac�a.-
			Postcondici�n: Modifica posici�n corriente colocando a la posici�n actual 
			               en el siguiente elemento.-
		*/
	virtual void anterior()=0;
		/*	Precondici�n: La lista no vac�a.-
			Postcondici�n: Modifica posici�n corriente colocando a la posici�n actual
			               en el elemento anterior.-
		*/
	virtual void comienzo()=0; 
		/*	Precondici�n: Lista no vac�a.-
			Postcondici�n: Modifica posici�n corriente, colocando a la posici�n actual.-
			               al comienzo de la lista.-
		*/
	virtual void final()=0; 
		/*	Precondici�n: Lista no vac�a.-
			Postcondici�n: Modifica posici�n corriente, colocando a la posici�n actual
			               al final de la lista.-
		*/
	virtual void borrar()=0;
		/*	Precondici�n: Lista no vac�a.-
			Postcondici�n: Borra el elemeto que se encuentra en la posici�n corriente.
						   S� el elemento a borrar es el �ltimo, la posici�n 
						   corriente es la anterior, en los dem�s casos la 
						   posici�n corriente es la siguiente. S� es el �nico
						   elemento queda vac�o.-
		*/
	virtual void borrarElemento(const Etype &x); 
		/*	Precondici�n: El elemento x deber� pertenecer a la lista.-
			Postcondici�n: Borra el elemento x de la lista.-
		*/	
	virtual int cardinal() const=0;
		/*	Precondici�n: ________
			Postcondici�n: //Retorna la cantidad de elementos de la lista.-
		*/	
};

template <class Etype>
void Lista<Etype>::borrarElemento(const Etype &x){
/*	comienzo();
	int i=0; bool encontre = false;
	while(i < cardinal() && !encontre){
		if(*(*elementoActual()) == *x){
			encontre = true;
			borrar();
		}
		i++;
		siguiente();
	}*/
};
