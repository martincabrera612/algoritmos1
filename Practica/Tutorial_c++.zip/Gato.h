#pragma once

#include "Mascota.h"

class Gato: public Mascota
{

//Desclaraci�n de variables
private: 
	int cantidadDeVidas;

public:
	
	//M�todos de Acceso y Modificaci�n
	int getVidas();
	void setVidas(int);
	
	void imprimir();

	//Constructor y Destructor
	Gato();
	virtual ~Gato();
};
