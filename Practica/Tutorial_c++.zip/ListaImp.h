#pragma once

/////////////////////ARCHIVOS INCLUIDOS/////////////////////
#include "Lista.h"
#include "NodoDoble.cpp"
#include <assert.h>
#include <iostream>
using namespace std;
////////////////////////////////////////////////////////////

template <class Etype>
class ListaImp : public Lista <Etype>
{

friend ostream& operator<<(ostream& out,const Lista<Etype> &lista);

typedef NodoDoble<Etype>* PtrNodo;

private:
	
	//Atributos de la clase/////////////
	PtrNodo	primero, actual, ultimo;
	int		cantElementos;	
	////////////////////////////////////
		
	void borrarLista();
	void borrar(PtrNodo a);

public:
	//Constructor
	ListaImp();
	//Constrictor copia
	ListaImp(Lista<Etype>* lista);

	virtual ~ListaImp()					{	borrarLista(); }

	//M�todos p�blicos////////////////////////////////////////////////////////////
	void	vacia();
	void	insertar(const Etype &x);
	bool	esVacia() const				{	return primero==NULL;	}
	Etype*	elementoActual()const		{	return actual->getDireccionDelDato();}
	void	siguiente()					{	assert(!esVacia()); actual= actual->getSiguiente();	}
	void	anterior()					{	actual = actual->getAnterior();	}
	int		cardinal()const					{	return cantElementos;	}
	void	comienzo()					{	actual = primero;		}
	void	final()						{	actual = ultimo;		}
	void	borrar()					{	borrar(actual);			}
	//////////////////////////////////////////////////////////////////////////////

	//Redefinici�n de Operadores //////////
	void	operator=(Lista<Etype>*	lista);
	///////////////////////////////////////
};
