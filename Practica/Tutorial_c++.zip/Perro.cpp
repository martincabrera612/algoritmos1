#pragma once

#include "Perro.h"
#include <iostream>
using namespace std;

Perro::Perro()
{
	patente= false;
}

Perro::~Perro()
{

}

void Perro::setPatente(bool unaP)
{
	patente= unaP;
}

bool Perro::getPatente()
{
	return patente;
}

void Perro::imprimir()
{
	cout<<"************ Perro ************"<<endl;
	this->imprimirMascota();
	if(this->getPatente())
	{
		cout<<"Tiene patente"<<endl;
	}
	else cout<<"No tiene patente"<<endl;
	cout<<"*******************************"<<endl<<endl;
}
