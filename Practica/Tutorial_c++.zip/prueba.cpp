
#include "Perro.h"
#include "Gato.h"
#include "ListaImp.cpp"
#include <iostream>
using namespace std;

class Prueba
{
	public:

		int menu()
		{
			cout<< "****************** MENU ******************"<<endl;
			cout<< "1- Crear un Perro"<<endl;
			cout<< "2- Crear un Gato"<<endl;
			cout<< "3- Salir"<<endl;
			cout<< "******************************************"<<endl;
			cout<<""<<endl;
			cout<< "Ingrese una opcion: ";
			int opcion;
			cin>> opcion;
			return opcion;
		};

		void crearMascota(Mascota *m)
		{
			cout<< "Ingrese el nombre: ";
			char* nombre= new char;
			cin>>  nombre;
			m->setNombre(nombre);
			cout<< "Ingrese la edad: ";
			int edad;
			cin>>  edad;
			m->setEdad(edad);
			cout<< "Ingrese la raza: ";
			char* raza= new char;
			cin>>  raza;
			m->setRaza(raza);
			bool tieneVacunas=true;
			int resp=2;
			cout<<"Tiene vacunas? " <<endl;
			cout<<"1- Si"<<endl;
			cout<<"2- No"<<endl;
			while(tieneVacunas)
			{
				cin>> resp;
				if(resp == 1)
				{
					cout<< "Ingrese el nombre de la vacuna: ";
					char* v= new char;
					cin>> v;
					cout<< "Ingrese el nombre del medico responsable: ";
					char* med= new char;
					cin>> med;
					m->agregarVacuna(v,med);

					cout<<"Tiene mas vacunas? " <<endl;
					cout<<"1- Si"<<endl;
					cout<<"2- No"<<endl;		
				}
				else if(resp == 2) tieneVacunas=false;
				else this->error();
			}

		}
			
		void crearPerro()
		{
			Perro *m= new Perro;
			this->crearMascota(m);
			cout<< "�Tiene patente?"<<endl;
			cout<<"1- Si"<<endl;
			cout<<"2- No"<<endl;
			int resp;
			cin>>resp;
			bool patente= false;
			bool ok= false;
			while(!ok)
			{
				switch (resp)
				{
					case 1:
						patente= true;
						ok= true;
					break;
			
					case 2:
						patente= false;
						ok= true;
					break;
				}
			}
			m->setPatente(patente);
			m->imprimir();
		}

		void crearGato()
		{
			Gato *m= new Gato;
			this->crearMascota(m);
			cout<< "Ingrese la cantidad de vidas: ";
			int vidas= 0;
			cin>>  vidas;
			m->setVidas(vidas);
			m->imprimir();
		}

		void error()
		{
			cout<<"Opcion incorrecta, intentelo nuevamente"<<endl;
		}

};

void main()
{
	Lista<char*>* lista = new ListaImp<char*>;
	lista->insertar ("1");
	lista->insertar ("2");
	lista->insertar ("3");
	
	cout << *lista;


	Prueba *prueba= new Prueba;
	int opcion;
	opcion= prueba->menu();
	
	while (opcion!=3)
	{
		if(opcion == 1)
		{
			prueba->crearPerro();	
			opcion= prueba->menu();
		}
		else if(opcion == 2)
		{
			prueba->crearGato();
			opcion= prueba->menu();
		}
		else
		{
			prueba->error();
			opcion= prueba->menu();
		}

	}
};
