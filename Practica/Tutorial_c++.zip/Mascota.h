#pragma once

#include "Lista.h"

struct Vacuna
{
	char* nombre;
	char* medicoResponsable;
};
typedef Vacuna *vacuna;

class Mascota  
{
private:
	char* raza;
	int edad;
	char* nombre;
	Lista<Vacuna*> *listaVacunas;

	void imprimirVacunas();

public:
	
	Lista<Vacuna *>* getListaVacunas();
	void agregarVacuna(char*,char*);
	void imprimirMascota();
	virtual void imprimir();
	char* getRaza();
	void setRaza(char*);
	int getEdad();
	void setEdad(int);
	char* getNombre();
	void setNombre(char*);
	Mascota();
	virtual ~Mascota();
};
